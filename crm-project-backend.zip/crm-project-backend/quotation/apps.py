from django.apps import AppConfig


class QuotationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'quotation'

    def ready(self):
        import quotation.signals  # noqa
